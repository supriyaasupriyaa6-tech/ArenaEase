/**
 * ArenaEase Core Script
 * Handles navigation, slot selection, and data persistence
 */

document.addEventListener("DOMContentLoaded", function() {
    // 1. Auto-fill Stadium Name from LocalStorage on relevant pages
    const venueHeader = document.getElementById('venueName');
    const hiddenInput = document.getElementById('hiddenStadiumName');
    const selectedStadium = localStorage.getItem('selectedStadium') || "M. Chinnaswamy Stadium";

    if (venueHeader) {
        venueHeader.innerText = "Check Availability: " + selectedStadium;
    }
    if (hiddenInput) {
        hiddenInput.value = selectedStadium;
    }

    // 2. Load Booking Data for Summary/Payment pages
    const bookingSummary = document.getElementById('bookingSummary');
    if (bookingSummary) {
        const data = JSON.parse(localStorage.getItem('currentUserBooking'));
        if (data) {
            updateBookingDisplay(data);
        }
    }

    // 3. Populate Sports based on Stadium (Example Logic)
    const sportPicker = document.getElementById('sportPicker');
    if (sportPicker) {
        populateSports(selectedStadium);
    }
});

/**
 * Navigates to the availability page and saves the stadium choice
 */
function goToAvailability(stadiumName) {
    localStorage.setItem('selectedStadium', stadiumName);
    // Adjust the URL to match your Django path (e.g., 'availability/')
    window.location.href = "/availability/"; 
}

/**
 * Used on the Stadiums page to jump straight to booking
 */
function goToBooking(stadiumName) {
    localStorage.setItem('selectedStadium', stadiumName);
    window.location.href = "/availability/";
}

/**
 * Populates the sport dropdown based on the stadium selected
 */
function populateSports(stadium) {
    const sportPicker = document.getElementById('sportPicker');
    if (!sportPicker) return;

    let sports = ["Cricket", "Football"]; // Default
    if (stadium.includes("Indoor")) sports = ["Badminton", "Basketball", "Tennis"];
    if (stadium.includes("Aquatic")) sports = ["Swimming"];
    if (stadium.includes("Combat")) sports = ["MMA"];

    sportPicker.innerHTML = sports.map(s => `<option value="${s}">${s}</option>`).join('');
}

/**
 * Handles the payment method UI toggle
 */
function togglePaymentFields(method) {
    const upi = document.getElementById('upiSection');
    const cash = document.getElementById('cashSection');
    
    if (upi) upi.style.display = (method === 'upi') ? 'block' : 'none';
    if (cash) cash.style.display = (method === 'cash') ? 'block' : 'none';
}

/**
 * Saves current booking attempt and moves to payment
 */
function makePayment(method) {
    const stadium = localStorage.getItem('selectedStadium');
    const slot = document.getElementById('slotPicker')?.value || "Morning Slot";
    
    const bookingDetails = {
        stadium: stadium,
        slot: slot,
        method: method,
        timestamp: new Date().toLocaleString()
    };

    localStorage.setItem('currentUserBooking', JSON.stringify(bookingDetails));
    
    alert("Processing " + method.toUpperCase() + " payment...");
    window.location.href = "/booking_confirmed/"; // Redirect to confirmation
}

/**
 * Simple back function for the "Back to Availability" button
 */
function goBack() {
    window.history.back();
}